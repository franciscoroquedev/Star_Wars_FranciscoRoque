
import UIKit

final class PeopleCell: UICollectionViewCell {
  
}
