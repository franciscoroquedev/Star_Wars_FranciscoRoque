
import UIKit

class PeopleViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
  }

}
